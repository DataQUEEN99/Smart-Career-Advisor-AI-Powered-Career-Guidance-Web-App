# AI Career Advisor

## Project Overview
- **Name**: AI Career Advisor
- **Goal**: An intelligent web application that analyzes user information and provides personalized career guidance, online course recommendations, and suitable job opportunities
- **Features**: 
  - Intelligent career path analysis based on skills, interests, education, and experience
  - Top 5 personalized career recommendations
  - 3 online courses per career path to fill skill gaps
  - 5 relevant job titles for each career path
  - Actionable career growth advice
  - Certification recommendations to increase competitiveness
  - JSON format output for easy parsing and integration

## URLs
- **Development**: https://3000-i3648bl0ore4u90ra5awl-8f57ffe2.sandbox.novita.ai
- **API Endpoint**: https://3000-i3648bl0ore4u90ra5awl-8f57ffe2.sandbox.novita.ai/api/analyze
- **GitHub**: (To be deployed)
- **Production (Cloudflare Pages)**: (To be deployed)

## Currently Completed Features

### ✅ Frontend Interface
- Modern, responsive web interface with TailwindCSS
- Interactive form for user input with validation
- Real-time career analysis with loading states
- Beautiful result display with color-coded sections:
  - Career path titles with numbered badges
  - Recommended courses with check icons
  - Job titles as styled tags
  - Career advice in highlighted boxes
  - Certification badges
- JSON output viewer with copy-to-clipboard functionality
- Smooth animations and hover effects

### ✅ Backend API
- RESTful API endpoint: `POST /api/analyze`
- Intelligent career path matching based on:
  - Skills analysis (technology, data, design, marketing, etc.)
  - Interest alignment
  - Education background
  - Work experience
- 10+ career path algorithms covering:
  - Full-Stack Web Development
  - Data Science / ML Engineering
  - Cloud/DevOps Engineering
  - Cybersecurity
  - UI/UX Design
  - Digital Marketing
  - Product Management / Business Analysis
  - Healthcare Data Analytics
  - Financial Analysis / Fintech
  - Content Strategy / Technical Writing
  - Project Management
  - Customer Success / Sales

### ✅ API Response Format
Returns structured JSON with:
```json
{
  "career_paths": [
    {
      "title": "Career Path Title",
      "courses": ["Course 1", "Course 2", "Course 3"],
      "jobs": ["Job 1", "Job 2", "Job 3", "Job 4", "Job 5"],
      "advice": "Actionable career growth advice",
      "certifications": ["Cert 1", "Cert 2"]
    }
  ]
}
```

## Functional Entry URIs

### 1. Home Page
- **Path**: `/`
- **Method**: GET
- **Description**: Main web interface with input form
- **Response**: HTML page with career advisor form

### 2. Career Analysis API
- **Path**: `/api/analyze`
- **Method**: POST
- **Content-Type**: application/json
- **Request Body**:
  ```json
  {
    "name": "User Name (optional)",
    "skills": "JavaScript, Python, Data Analysis (required)",
    "interests": "Technology, Design, Business (required)",
    "education": "Bachelor's in Computer Science (required)",
    "experience": "2 years as Developer (optional)",
    "resumeText": "Full resume text (optional)"
  }
  ```
- **Success Response**: 200 OK with career paths JSON
- **Error Response**: 400 Bad Request if required fields are missing

### 3. Example API Call
```bash
curl -X POST https://3000-i3648bl0ore4u90ra5awl-8f57ffe2.sandbox.novita.ai/api/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "skills": "JavaScript, Python, React",
    "interests": "Web Development, Technology",
    "education": "Bachelor in Computer Science",
    "experience": "2 years as Junior Developer"
  }'
```

## Features Not Yet Implemented

### 🔄 Planned Enhancements
1. **AI-Powered Analysis**: Integration with OpenAI or Claude API for more sophisticated career analysis
2. **Resume Parsing**: Automatic extraction of skills and experience from uploaded resume files
3. **Salary Information**: Expected salary ranges for each career path and job title
4. **Location-Based Recommendations**: Job market insights based on geographic location
5. **Career Roadmap**: Visual timeline and milestones for career progression
6. **Save & Export**: 
   - Save analysis results to user accounts
   - Export to PDF format
   - Email recommendations
7. **Course Integration**: Direct links to course platforms (Udemy, Coursera, etc.)
8. **Job Board Integration**: Real job postings from Indeed, LinkedIn APIs
9. **Skill Gap Analysis**: Visual representation of current vs required skills
10. **Personalized Learning Path**: Step-by-step learning plan with time estimates
11. **Data Persistence**: 
    - User accounts with authentication
    - Save career analysis history
    - Track learning progress
12. **Advanced Filters**: Filter recommendations by industry, remote work, salary range
13. **Comparison Tool**: Compare multiple career paths side-by-side
14. **Success Stories**: Real examples of people in recommended career paths

## Data Architecture

### Data Models
**User Input Model**:
```typescript
{
  name: string
  skills: string[]
  interests: string
  education: string
  experience: string
  resumeText?: string
}
```

**Career Path Model**:
```typescript
{
  title: string
  courses: string[3]
  jobs: string[5]
  advice: string
  certifications: string[2]
}
```

### Storage Services
- **Current**: In-memory processing (stateless, no data persistence)
- **Recommended for Future**: 
  - Cloudflare D1 Database for user accounts and analysis history
  - Cloudflare KV for caching course and job recommendations
  - Cloudflare R2 for storing uploaded resume files

### Data Flow
1. User fills form on frontend → 
2. JavaScript sends POST request to `/api/analyze` → 
3. Backend analyzes skills/interests/education → 
4. Algorithm matches with career paths → 
5. Returns top 5 career recommendations with courses, jobs, advice, certifications → 
6. Frontend displays results in beautiful UI + JSON format

## User Guide

### How to Use the AI Career Advisor

1. **Access the Application**: Open https://3000-i3648bl0ore4u90ra5awl-8f57ffe2.sandbox.novita.ai in your browser

2. **Fill in Your Information**:
   - **Name**: Your full name (optional)
   - **Skills**: Enter your skills separated by commas (e.g., "JavaScript, Python, Marketing")
   - **Interests**: Describe your career interests (e.g., "Technology, Web Development, Data Science")
   - **Education**: Your degree and field of study (e.g., "Bachelor's in Computer Science")
   - **Experience**: Describe your work experience (optional)
   - **Resume Text**: Paste your resume for more detailed analysis (optional)

3. **Submit for Analysis**: Click the "Analyze My Career Path" button

4. **Review Your Results**: The system will provide:
   - Top 5 career paths tailored to your profile
   - 3 recommended online courses for each career path
   - 5 relevant job titles you can pursue
   - Actionable advice for career growth
   - Certifications that will make you more competitive

5. **Copy JSON Output**: Use the "Copy JSON" button to get the structured data for integration with other tools

### Example Use Cases

**Recent Graduate**: Input your degree and skills learned in school to discover entry-level career paths and courses to get started

**Career Changer**: Enter your transferable skills and new interests to find career paths that leverage your experience

**Professional Growth**: Input your current role and skills to discover advanced career paths and certifications to progress

**API Integration**: Use the `/api/analyze` endpoint to integrate career recommendations into your own applications

## Technical Architecture

### Tech Stack
- **Framework**: Hono (Lightweight web framework for Cloudflare Workers)
- **Runtime**: Cloudflare Workers / Pages (Edge runtime)
- **Frontend**: 
  - TailwindCSS (Utility-first CSS framework via CDN)
  - FontAwesome (Icons via CDN)
  - Axios (HTTP client via CDN)
  - Vanilla JavaScript (No heavy frameworks)
- **Backend**: TypeScript + Hono
- **Build Tool**: Vite
- **Deployment Tool**: Wrangler (Cloudflare CLI)

### Project Structure
```
webapp/
├── src/
│   ├── index.tsx              # Main Hono application
│   └── renderer.tsx           # (Original, not used)
├── public/
│   └── static/               # Static assets
│       └── style.css
├── dist/                      # Build output
│   └── _worker.js            # Compiled Cloudflare Worker
├── ecosystem.config.cjs      # PM2 configuration
├── wrangler.jsonc            # Cloudflare configuration
├── package.json              # Dependencies and scripts
├── vite.config.ts            # Vite build configuration
├── tsconfig.json             # TypeScript configuration
└── README.md                 # This file
```

### API Design
- **Pattern**: RESTful API with JSON responses
- **CORS**: Enabled for API routes
- **Error Handling**: Proper HTTP status codes (400, 500)
- **Validation**: Required field checking

## Recommended Next Steps

### Priority 1: AI Integration
1. Integrate OpenAI/Claude API for more sophisticated career analysis
2. Use AI to parse resume text and extract skills/experience automatically
3. Generate more personalized advice based on user's unique situation

### Priority 2: Enhanced User Experience
1. Add user authentication (Cloudflare Access or Auth0)
2. Implement data persistence with Cloudflare D1 database
3. Add ability to save and track multiple analyses
4. Create a dashboard to view analysis history

### Priority 3: Data Enrichment
1. Integrate real job postings from job board APIs
2. Add current salary data for each career path
3. Include job market demand metrics and trends
4. Add location-based job opportunities

### Priority 4: Course & Certification Integration
1. Add direct links to course platforms
2. Show course pricing and duration
3. Track course completion and learning progress
4. Add course reviews and ratings

### Priority 5: Deployment & Scaling
1. Deploy to Cloudflare Pages for global edge delivery
2. Set up custom domain
3. Implement analytics to track usage
4. Add SEO optimization for organic traffic

## Development Commands

### Local Development
```bash
# Install dependencies
npm install

# Build the project
npm run build

# Start development server (sandbox)
npm run dev:sandbox

# Or use PM2 (recommended)
pm2 start ecosystem.config.cjs

# Check service status
pm2 list

# View logs
pm2 logs webapp --nostream

# Test the service
curl http://localhost:3000
npm run test
```

### Git Commands
```bash
# Initialize git repository
git init

# Commit changes
npm run git:commit "Your commit message"

# Check status
npm run git:status
```

### Deployment to Cloudflare Pages
```bash
# Build for production
npm run build

# Deploy to Cloudflare Pages
npm run deploy

# Or deploy with specific project name
npm run deploy:prod
```

## Deployment

### Platform
- **Development**: Sandbox environment with PM2
- **Production**: Ready for Cloudflare Pages deployment

### Status
- ✅ Development Server Active
- ✅ API Endpoints Functional
- ✅ Frontend Interface Complete
- ⏳ GitHub Repository (Pending)
- ⏳ Cloudflare Pages Production (Pending)

### Last Updated
December 28, 2025

## License
MIT License - Free to use for personal and commercial projects

## Support
For questions or issues, please contact the development team or open an issue on GitHub (once deployed).

---

**Built with ❤️ using Hono, Cloudflare Workers, and TailwindCSS**
