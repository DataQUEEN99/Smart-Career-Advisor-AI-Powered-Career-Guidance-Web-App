import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'

const app = new Hono()

// Enable CORS for API routes
app.use('/api/*', cors())

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))

// Career advisor AI logic
function analyzeCareerPath(userData: {
  name: string
  skills: string[]
  interests: string
  education: string
  experience: string
  resumeText?: string
}) {
  const { skills, interests, education, experience } = userData

  // Analyze skills and interests to determine career paths
  const skillsLower = skills.map(s => s.toLowerCase())
  const interestsLower = interests.toLowerCase()
  const educationLower = education.toLowerCase()

  const careerPaths: any[] = []

  // Tech/Software Development
  if (skillsLower.some(s => ['javascript', 'python', 'java', 'coding', 'programming', 'software', 'web'].includes(s)) ||
      interestsLower.includes('technology') || interestsLower.includes('coding') || interestsLower.includes('software')) {
    careerPaths.push({
      title: "Full-Stack Web Developer",
      courses: [
        "Full-Stack Web Development - The Complete Bootcamp (Udemy)",
        "React & Node.js - Advanced Web Development (Coursera)",
        "Database Design and SQL Mastery (Pluralsight)"
      ],
      jobs: [
        "Full-Stack Developer",
        "Frontend Developer",
        "Backend Developer",
        "Web Application Developer",
        "JavaScript Engineer"
      ],
      advice: "Build a strong portfolio with 3-5 real-world projects showcasing full-stack capabilities. Contribute to open-source projects on GitHub. Stay updated with modern frameworks like React, Vue, or Angular. Master RESTful API design and database management.",
      certifications: [
        "AWS Certified Developer - Associate",
        "Google Professional Cloud Developer"
      ]
    })
  }

  // Data Science/Analytics
  if (skillsLower.some(s => ['python', 'data', 'statistics', 'analytics', 'sql', 'machine learning', 'ai'].includes(s)) ||
      interestsLower.includes('data') || interestsLower.includes('analytics') || interestsLower.includes('ai')) {
    careerPaths.push({
      title: "Data Scientist / ML Engineer",
      courses: [
        "Machine Learning Specialization by Andrew Ng (Coursera)",
        "Python for Data Science and Machine Learning (Udemy)",
        "Deep Learning and Neural Networks (DeepLearning.AI)"
      ],
      jobs: [
        "Data Scientist",
        "Machine Learning Engineer",
        "Data Analyst",
        "AI Research Engineer",
        "Business Intelligence Analyst"
      ],
      advice: "Master Python libraries like Pandas, NumPy, scikit-learn, and TensorFlow. Work on Kaggle competitions to build practical experience. Create a portfolio showcasing data visualization and predictive modeling projects. Learn cloud platforms like AWS or GCP for ML deployment.",
      certifications: [
        "Google Data Analytics Professional Certificate",
        "AWS Certified Machine Learning - Specialty"
      ]
    })
  }

  // Cloud/DevOps
  if (skillsLower.some(s => ['cloud', 'aws', 'azure', 'devops', 'docker', 'kubernetes', 'linux'].includes(s)) ||
      interestsLower.includes('cloud') || interestsLower.includes('infrastructure')) {
    careerPaths.push({
      title: "Cloud/DevOps Engineer",
      courses: [
        "AWS Solutions Architect - Complete Course (A Cloud Guru)",
        "Docker and Kubernetes: The Complete Guide (Udemy)",
        "DevOps Engineering and CI/CD Pipelines (LinkedIn Learning)"
      ],
      jobs: [
        "DevOps Engineer",
        "Cloud Solutions Architect",
        "Site Reliability Engineer (SRE)",
        "Infrastructure Engineer",
        "Platform Engineer"
      ],
      advice: "Gain hands-on experience with major cloud providers (AWS, Azure, GCP). Master infrastructure-as-code tools like Terraform and Ansible. Learn container orchestration with Kubernetes. Develop strong scripting skills in Python or Bash. Focus on automation and CI/CD pipelines.",
      certifications: [
        "AWS Certified Solutions Architect - Associate",
        "Certified Kubernetes Administrator (CKA)"
      ]
    })
  }

  // Cybersecurity
  if (skillsLower.some(s => ['security', 'cybersecurity', 'penetration', 'ethical hacking', 'networking'].includes(s)) ||
      interestsLower.includes('security') || interestsLower.includes('cybersecurity')) {
    careerPaths.push({
      title: "Cybersecurity Analyst",
      courses: [
        "Cybersecurity Specialization (Coursera - University of Maryland)",
        "Ethical Hacking and Penetration Testing (Udemy)",
        "CompTIA Security+ Complete Course (Professor Messer)"
      ],
      jobs: [
        "Security Analyst",
        "Penetration Tester",
        "Security Engineer",
        "SOC Analyst",
        "Information Security Specialist"
      ],
      advice: "Start with CompTIA Security+ certification. Practice in cybersecurity labs like HackTheBox or TryHackMe. Stay updated on the latest threats and vulnerabilities. Develop strong networking knowledge and understanding of security frameworks like NIST. Consider specializing in areas like application security or cloud security.",
      certifications: [
        "CompTIA Security+",
        "Certified Ethical Hacker (CEH)"
      ]
    })
  }

  // UI/UX Design
  if (skillsLower.some(s => ['design', 'ui', 'ux', 'figma', 'adobe', 'creative', 'photoshop'].includes(s)) ||
      interestsLower.includes('design') || interestsLower.includes('user experience')) {
    careerPaths.push({
      title: "UI/UX Designer",
      courses: [
        "Google UX Design Professional Certificate (Coursera)",
        "User Experience Design Fundamentals (Udemy)",
        "Advanced Figma - Complete UI/UX Design Course (Skillshare)"
      ],
      jobs: [
        "UI/UX Designer",
        "Product Designer",
        "Interaction Designer",
        "Visual Designer",
        "User Researcher"
      ],
      advice: "Build a strong design portfolio with 5-7 case studies showing your design process. Master design tools like Figma, Sketch, and Adobe XD. Learn user research methodologies and usability testing. Stay updated with design trends and accessibility standards. Consider learning basic HTML/CSS to collaborate better with developers.",
      certifications: [
        "Google UX Design Professional Certificate",
        "Nielsen Norman Group UX Certification"
      ]
    })
  }

  // Digital Marketing
  if (skillsLower.some(s => ['marketing', 'seo', 'social media', 'content', 'advertising'].includes(s)) ||
      interestsLower.includes('marketing') || interestsLower.includes('advertising')) {
    careerPaths.push({
      title: "Digital Marketing Specialist",
      courses: [
        "Google Digital Marketing & E-commerce Professional Certificate (Coursera)",
        "Advanced SEO and Content Marketing (HubSpot Academy)",
        "Facebook and Instagram Marketing Mastery (Udemy)"
      ],
      jobs: [
        "Digital Marketing Manager",
        "SEO Specialist",
        "Social Media Manager",
        "Content Marketing Manager",
        "PPC Specialist"
      ],
      advice: "Get certified in Google Ads and Google Analytics. Build your personal brand on LinkedIn. Create case studies showing ROI from marketing campaigns. Learn data analytics to measure campaign effectiveness. Stay updated with algorithm changes and emerging platforms.",
      certifications: [
        "Google Ads Certification",
        "HubSpot Content Marketing Certification"
      ]
    })
  }

  // Business/Management
  if (skillsLower.some(s => ['management', 'business', 'leadership', 'strategy', 'mba'].includes(s)) ||
      educationLower.includes('business') || educationLower.includes('management')) {
    careerPaths.push({
      title: "Product Manager / Business Analyst",
      courses: [
        "Product Management Fundamentals (Udemy)",
        "Business Analysis and Process Management (Coursera)",
        "Agile and Scrum Masterclass (Pluralsight)"
      ],
      jobs: [
        "Product Manager",
        "Business Analyst",
        "Project Manager",
        "Strategy Consultant",
        "Operations Manager"
      ],
      advice: "Develop strong analytical and communication skills. Learn product management frameworks like Agile/Scrum. Gain technical literacy to work effectively with engineering teams. Build a track record of successful product launches or business improvements. Network actively in product management communities.",
      certifications: [
        "Certified Scrum Product Owner (CSPO)",
        "Project Management Professional (PMP)"
      ]
    })
  }

  // Healthcare/Biotech
  if (skillsLower.some(s => ['healthcare', 'medical', 'nursing', 'biology', 'biotech'].includes(s)) ||
      educationLower.includes('health') || educationLower.includes('medical') || educationLower.includes('biology')) {
    careerPaths.push({
      title: "Healthcare Data Analyst / Clinical Research",
      courses: [
        "Healthcare Analytics and Decision Making (Coursera - MIT)",
        "Clinical Research and Regulatory Affairs (Udemy)",
        "Health Informatics Specialization (Johns Hopkins)"
      ],
      jobs: [
        "Healthcare Data Analyst",
        "Clinical Research Coordinator",
        "Health Informatics Specialist",
        "Medical Science Liaison",
        "Healthcare Consultant"
      ],
      advice: "Combine healthcare knowledge with data analytics skills. Stay updated on healthcare regulations like HIPAA. Consider specializing in areas like clinical trials, health informatics, or healthcare IT. Build knowledge of electronic health records (EHR) systems. Network with healthcare professionals and join industry associations.",
      certifications: [
        "Certified Healthcare Data Analyst (CHDA)",
        "Clinical Research Coordinator Certification"
      ]
    })
  }

  // Finance/Accounting
  if (skillsLower.some(s => ['finance', 'accounting', 'financial', 'economics', 'investment'].includes(s)) ||
      educationLower.includes('finance') || educationLower.includes('accounting') || educationLower.includes('economics')) {
    careerPaths.push({
      title: "Financial Analyst / Fintech Specialist",
      courses: [
        "Financial Modeling and Valuation (Coursera - Wharton)",
        "Python for Finance and Algorithmic Trading (Udemy)",
        "CFA Level 1 Preparation Course (Kaplan)"
      ],
      jobs: [
        "Financial Analyst",
        "Investment Analyst",
        "Risk Analyst",
        "Fintech Product Manager",
        "Quantitative Analyst"
      ],
      advice: "Master Excel and financial modeling. Learn Python for financial data analysis. Consider pursuing CFA or CPA certification depending on your focus. Gain knowledge of fintech trends like blockchain and cryptocurrencies. Build a portfolio showing financial analysis projects with real-world data.",
      certifications: [
        "Chartered Financial Analyst (CFA) Level 1",
        "Financial Risk Manager (FRM)"
      ]
    })
  }

  // Content Creation/Writing
  if (skillsLower.some(s => ['writing', 'content', 'journalism', 'copywriting', 'creative'].includes(s)) ||
      interestsLower.includes('writing') || interestsLower.includes('content creation')) {
    careerPaths.push({
      title: "Content Strategist / Technical Writer",
      courses: [
        "Technical Writing Fundamentals (Google - Coursera)",
        "Content Strategy for Professionals (Northwestern - Coursera)",
        "SEO Content Writing Masterclass (Udemy)"
      ],
      jobs: [
        "Content Strategist",
        "Technical Writer",
        "Copywriter",
        "Content Marketing Manager",
        "Documentation Specialist"
      ],
      advice: "Build a diverse writing portfolio across different formats and industries. Learn SEO and content marketing principles. Develop subject matter expertise in high-demand areas like technology or healthcare. Master content management systems. Consider freelancing to gain varied experience quickly.",
      certifications: [
        "HubSpot Content Marketing Certification",
        "Google Technical Writing Certification"
      ]
    })
  }

  // If we have less than 3 career paths, add some general ones
  if (careerPaths.length < 3) {
    // Add Project Management if not already there
    if (!careerPaths.some(p => p.title.includes('Project Manager'))) {
      careerPaths.push({
        title: "Project Manager",
        courses: [
          "Project Management Professional (PMP) Prep (Udemy)",
          "Agile Project Management (Coursera - Google)",
          "Microsoft Project Complete Training (LinkedIn Learning)"
        ],
        jobs: [
          "Project Manager",
          "Program Manager",
          "Scrum Master",
          "Agile Coach",
          "PMO Analyst"
        ],
        advice: "Get PMP or CAPM certification. Gain experience with project management tools like Jira, Asana, or MS Project. Develop strong communication and stakeholder management skills. Learn both waterfall and agile methodologies. Build a track record of delivering projects on time and within budget.",
        certifications: [
          "Project Management Professional (PMP)",
          "Certified Scrum Master (CSM)"
        ]
      })
    }

    // Add Sales/Customer Success
    careerPaths.push({
      title: "Customer Success Manager / Sales",
      courses: [
        "Customer Success Fundamentals (Gainsight)",
        "Strategic Sales and B2B Marketing (LinkedIn Learning)",
        "SaaS Sales Masterclass (Udemy)"
      ],
      jobs: [
        "Customer Success Manager",
        "Account Executive",
        "Sales Development Representative",
        "Solutions Consultant",
        "Business Development Manager"
      ],
      advice: "Develop strong relationship-building and communication skills. Learn CRM platforms like Salesforce or HubSpot. Focus on understanding customer needs and providing value. Track metrics like customer retention and upsell rates. Consider specializing in a specific industry or product type.",
      certifications: [
        "Salesforce Certified Administrator",
        "HubSpot Sales Software Certification"
      ]
    })
  }

  // Return top 5 career paths
  return {
    career_paths: careerPaths.slice(0, 5)
  }
}

// API endpoint for career analysis
app.post('/api/analyze', async (c) => {
  try {
    const body = await c.req.json()
    
    const userData = {
      name: body.name || 'User',
      skills: body.skills ? body.skills.split(',').map((s: string) => s.trim()) : [],
      interests: body.interests || '',
      education: body.education || '',
      experience: body.experience || '',
      resumeText: body.resumeText || ''
    }

    // Validate input
    if (userData.skills.length === 0 && !userData.interests && !userData.education) {
      return c.json({ 
        error: 'Please provide at least skills, interests, or education information.' 
      }, 400)
    }

    const result = analyzeCareerPath(userData)
    
    return c.json(result)
  } catch (error) {
    console.error('Error analyzing career path:', error)
    return c.json({ error: 'Failed to analyze career path' }, 500)
  }
})

// Home page
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>AI Career Advisor</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 min-h-screen">
        <div class="container mx-auto px-4 py-8 max-w-6xl">
            <!-- Header -->
            <div class="text-center mb-12">
                <h1 class="text-5xl font-bold text-gray-800 mb-4">
                    <i class="fas fa-briefcase text-indigo-600 mr-3"></i>
                    AI Career Advisor
                </h1>
                <p class="text-xl text-gray-600">
                    Get personalized career guidance, course recommendations, and job opportunities
                </p>
            </div>

            <!-- Input Form -->
            <div class="bg-white rounded-2xl shadow-xl p-8 mb-8">
                <h2 class="text-2xl font-bold text-gray-800 mb-6">
                    <i class="fas fa-user-circle text-indigo-500 mr-2"></i>
                    Your Information
                </h2>
                
                <form id="careerForm" class="space-y-6">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-user mr-2"></i>Name
                        </label>
                        <input type="text" id="name" 
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                               placeholder="John Doe">
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-code mr-2"></i>Skills <span class="text-red-500">*</span>
                        </label>
                        <input type="text" id="skills" required
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                               placeholder="JavaScript, Python, Data Analysis, Marketing">
                        <p class="text-xs text-gray-500 mt-1">Comma-separated list of your skills</p>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-heart mr-2"></i>Interests <span class="text-red-500">*</span>
                        </label>
                        <input type="text" id="interests" required
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                               placeholder="Technology, Design, Business, Healthcare">
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-graduation-cap mr-2"></i>Education <span class="text-red-500">*</span>
                        </label>
                        <input type="text" id="education" required
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                               placeholder="Bachelor's in Computer Science">
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-briefcase mr-2"></i>Experience
                        </label>
                        <textarea id="experience" rows="3"
                                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                                  placeholder="2 years as a Junior Developer at XYZ Company"></textarea>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-file-alt mr-2"></i>Resume Text (Optional)
                        </label>
                        <textarea id="resumeText" rows="4"
                                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                                  placeholder="Paste your resume text here..."></textarea>
                    </div>

                    <button type="submit" 
                            class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 px-6 rounded-lg transition duration-300 transform hover:scale-105 shadow-lg">
                        <i class="fas fa-robot mr-2"></i>
                        Analyze My Career Path
                    </button>
                </form>
            </div>

            <!-- Loading State -->
            <div id="loading" class="hidden text-center py-12">
                <div class="inline-block animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-indigo-600"></div>
                <p class="text-gray-600 mt-4 text-lg">Analyzing your career profile...</p>
            </div>

            <!-- Results -->
            <div id="results" class="hidden space-y-6"></div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
        <script>
            const form = document.getElementById('careerForm');
            const loading = document.getElementById('loading');
            const results = document.getElementById('results');

            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                
                // Show loading
                loading.classList.remove('hidden');
                results.classList.add('hidden');
                results.innerHTML = '';

                const formData = {
                    name: document.getElementById('name').value,
                    skills: document.getElementById('skills').value,
                    interests: document.getElementById('interests').value,
                    education: document.getElementById('education').value,
                    experience: document.getElementById('experience').value,
                    resumeText: document.getElementById('resumeText').value
                };

                try {
                    const response = await axios.post('/api/analyze', formData);
                    displayResults(response.data);
                } catch (error) {
                    console.error('Error:', error);
                    results.innerHTML = \`
                        <div class="bg-red-100 border border-red-400 text-red-700 px-6 py-4 rounded-lg">
                            <i class="fas fa-exclamation-circle mr-2"></i>
                            <strong>Error:</strong> \${error.response?.data?.error || 'Failed to analyze career path'}
                        </div>
                    \`;
                    results.classList.remove('hidden');
                } finally {
                    loading.classList.add('hidden');
                }
            });

            function displayResults(data) {
                const careerPaths = data.career_paths;
                
                let html = \`
                    <div class="bg-white rounded-2xl shadow-xl p-8 mb-8">
                        <h2 class="text-3xl font-bold text-gray-800 mb-6">
                            <i class="fas fa-chart-line text-green-500 mr-3"></i>
                            Your Personalized Career Recommendations
                        </h2>
                        <p class="text-gray-600 mb-8">Based on your skills, interests, and experience, here are the top career paths for you:</p>
                    </div>
                \`;

                careerPaths.forEach((path, index) => {
                    html += \`
                        <div class="bg-white rounded-2xl shadow-xl p-8 mb-6 transform hover:scale-[1.02] transition duration-300">
                            <!-- Career Title -->
                            <div class="flex items-center mb-6">
                                <div class="bg-indigo-100 text-indigo-600 rounded-full w-12 h-12 flex items-center justify-center font-bold text-xl mr-4">
                                    \${index + 1}
                                </div>
                                <h3 class="text-2xl font-bold text-gray-800">\${path.title}</h3>
                            </div>

                            <!-- Recommended Courses -->
                            <div class="mb-6">
                                <h4 class="text-lg font-semibold text-gray-700 mb-3 flex items-center">
                                    <i class="fas fa-book text-blue-500 mr-2"></i>
                                    Recommended Courses
                                </h4>
                                <ul class="space-y-2">
                                    \${path.courses.map(course => \`
                                        <li class="flex items-start">
                                            <i class="fas fa-check-circle text-green-500 mr-2 mt-1"></i>
                                            <span class="text-gray-700">\${course}</span>
                                        </li>
                                    \`).join('')}
                                </ul>
                            </div>

                            <!-- Job Titles -->
                            <div class="mb-6">
                                <h4 class="text-lg font-semibold text-gray-700 mb-3 flex items-center">
                                    <i class="fas fa-briefcase text-purple-500 mr-2"></i>
                                    Relevant Job Titles
                                </h4>
                                <div class="flex flex-wrap gap-2">
                                    \${path.jobs.map(job => \`
                                        <span class="bg-purple-100 text-purple-700 px-4 py-2 rounded-full text-sm font-medium">
                                            \${job}
                                        </span>
                                    \`).join('')}
                                </div>
                            </div>

                            <!-- Career Advice -->
                            <div class="mb-6">
                                <h4 class="text-lg font-semibold text-gray-700 mb-3 flex items-center">
                                    <i class="fas fa-lightbulb text-yellow-500 mr-2"></i>
                                    Career Growth Advice
                                </h4>
                                <p class="text-gray-700 leading-relaxed bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-400">
                                    \${path.advice}
                                </p>
                            </div>

                            <!-- Certifications -->
                            <div>
                                <h4 class="text-lg font-semibold text-gray-700 mb-3 flex items-center">
                                    <i class="fas fa-certificate text-red-500 mr-2"></i>
                                    Recommended Certifications
                                </h4>
                                <div class="flex flex-wrap gap-2">
                                    \${path.certifications.map(cert => \`
                                        <span class="bg-red-100 text-red-700 px-4 py-2 rounded-full text-sm font-medium">
                                            <i class="fas fa-award mr-1"></i>
                                            \${cert}
                                        </span>
                                    \`).join('')}
                                </div>
                            </div>
                        </div>
                    \`;
                });

                // Add JSON output section
                html += \`
                    <div class="bg-gray-800 rounded-2xl shadow-xl p-8 mt-8">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-xl font-bold text-white">
                                <i class="fas fa-code text-green-400 mr-2"></i>
                                JSON Output
                            </h3>
                            <button onclick="copyJSON()" class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition">
                                <i class="fas fa-copy mr-2"></i>Copy JSON
                            </button>
                        </div>
                        <pre id="jsonOutput" class="bg-gray-900 text-green-400 p-4 rounded-lg overflow-x-auto text-sm font-mono">\${JSON.stringify(data, null, 2)}</pre>
                    </div>
                \`;

                results.innerHTML = html;
                results.classList.remove('hidden');
                
                // Scroll to results
                results.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }

            function copyJSON() {
                const jsonText = document.getElementById('jsonOutput').textContent;
                navigator.clipboard.writeText(jsonText).then(() => {
                    alert('JSON copied to clipboard!');
                });
            }

            // Example data for quick testing
            window.fillExample = function() {
                document.getElementById('name').value = 'Sarah Johnson';
                document.getElementById('skills').value = 'JavaScript, Python, React, Data Analysis, SQL';
                document.getElementById('interests').value = 'Technology, Web Development, Data Science';
                document.getElementById('education').value = "Bachelor's in Computer Science";
                document.getElementById('experience').value = '2 years as Junior Full-Stack Developer';
            }
        </script>
    </body>
    </html>
  `)
})

export default app
